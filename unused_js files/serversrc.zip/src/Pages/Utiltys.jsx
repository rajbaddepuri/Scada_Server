  var IP = "192.168.0.45"
export default IP ;